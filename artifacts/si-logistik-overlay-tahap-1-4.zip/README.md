# SI-LOGISTIK — Overlay Kumulatif Tahap 1–4

Aplikasi inventaris logistik untuk Bagian Logistik SMA Taruna Nusantara IKN. Paket ini melanjutkan proyek yang sudah memiliki setup/autentikasi, skema database, model, CRUD master barang, kategori, satuan, lokasi, barcode EAN-13 internal, soft delete, unggah foto, dan audit log. Tahap 4 menambahkan transaksi stok masuk/keluar serta alur POS barcode.

## Kondisi proyek dan keputusan stack

Workspace saat ini memakai Laravel 13, PHP 8.3+, Bootstrap 5.3, Alpine.js, Vite, DataTables 3.1.3 (`datatables.net-bs5`), dan SQLite untuk PHPUnit. Proyek belum memakai Yajra atau jQuery. Ini berbeda dari rencana awal Laravel 12, Yajra DataTables 12, jQuery, dan DataTables 2.3.8; pengguna telah memilih melanjutkan Tahap 4 dengan stack yang sudah terpasang. Pertahankan keputusan ini untuk pekerjaan berikutnya.

Frontend dibundel lokal oleh Vite, tanpa CDN. `jsbarcode` menghasilkan barcode Code 128 dan `qrcode` menghasilkan QR di browser. Tidak ada migration baru pada Tahap 4 karena `transactions`, `transaction_details`, `stok_mutasi`, `aktivitas_log`, dan `nomor_urut` sudah tersedia.

## Isi overlay

| Bagian | Cakupan |
|---|---|
| Setup dan autentikasi | Login admin tunggal, profil, konfigurasi aplikasi dan bahasa Indonesia |
| Database | 11 migration domain, tabel bawaan Laravel, seeder idempotent |
| Tahap 3 | Model/relasi, enum, factory, CRUD master, barcode internal, foto, DataTables, filter, audit |
| Tahap 4 | `NomorTransaksiService`, `StokService`, Form Request, POS masuk/keluar, pencarian barcode, daftar/detail transaksi, ledger, audit, label Code 128 + QR |
| Frontend | Blade, Bootstrap SCSS, Bootstrap Icons, Alpine, Axios, DataTables, JsBarcode, QRCode |
| Pemeriksaan | PHPUnit, `tools/audit.ps1`, `tools/audit.py` (Python diperlukan untuk skrip ini) |

## Instalasi baru

Instruksi dasar overlay awal ditulis untuk skeleton Laravel 12. Karena workspace sekarang mengikuti Laravel 13, gunakan versi yang sama dengan proyek ini untuk instalasi ulang agar dependensi dan lockfile konsisten. Jangan menyalin `vendor/` atau `node_modules/` ke paket overlay.

```powershell
# Di folder proyek
Copy-Item .env.example .env
composer install
php artisan key:generate
# Buat database MySQL/MariaDB si_logistik dan sesuaikan DB_* di .env
php artisan migrate --seed
php artisan storage:link
npm install
npm run build
php artisan serve
```

`.env.example` menetapkan `APP_LOCALE=id` dan `APP_TIMEZONE=Asia/Makassar`. Buat database dengan charset `utf8mb4`, lalu atur `DB_DATABASE`, `DB_USERNAME`, dan `DB_PASSWORD`. Seeder membuat akun awal `admin@logistik.local`; atur `ADMIN_EMAIL`, `ADMIN_NAME`, dan `ADMIN_PASSWORD` sebelum `php artisan db:seed`. Jika kata sandi kosong, seeder membuat kata sandi acak dan menampilkannya satu kali di terminal. Nilai nama aplikasi/instansi awal dapat diatur lewat `LOGISTIK_NAMA_APLIKASI`, `LOGISTIK_NAMA_SINGKAT`, dan `LOGISTIK_NAMA_INSTANSI`.

```sql
CREATE DATABASE si_logistik CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Jika file overlay ditempel ke checkout yang sudah ada, salin berkas aplikasi dan migrasi kumulatif tanpa menimpa `.env`, `vendor/`, atau `node_modules/`. Lalu jalankan:

```powershell
composer install
npm install
php artisan migrate --seed
php artisan storage:link
npm run build
php artisan test
```

Seeder dapat dijalankan ulang. Untuk reset data pengembangan saja: `php artisan migrate:fresh --seed`.

## Aturan transaksi Tahap 4

- Nomor transaksi memakai awalan `IN`, `OUT`, tanggal aplikasi (`Asia/Makassar`), dan urutan empat digit. Urutan kembali ke `0001` untuk jenis dan tanggal baru.
- Baris `nomor_urut` dibuat dengan `insertOrIgnore`, dikunci `lockForUpdate`, lalu dinaikkan di dalam transaksi database yang sama. Indeks unik dan `transactions.nomor_transaksi` menjadi lapisan pengaman tambahan.
- Semua barang yang terlibat dikunci dalam urutan ID naik. Barang nonaktif/terhapus ditolak.
- Jumlah dari barcode yang sama digabung, baik di keranjang browser maupun di server. Satu barang hanya memiliki satu baris detail per transaksi.
- Stok baru berubah sesudah Simpan ditekan. Transaksi, detail, stok, ledger, nomor, dan audit log disimpan di satu `DB::transaction()`; satu barang gagal berarti seluruh perubahan dibatalkan.
- Barang keluar tidak boleh melampaui stok. Pesan bisnis: `Stok tidak mencukupi. Stok tersedia: N.`
- Setiap barang dalam transaksi mendapat tepat satu baris `stok_mutasi`. Transaksi bersifat immutable; Tahap 4 tidak menyediakan edit atau hapus transaksi.
- Scanner USB bertindak seperti keyboard: fokus pada input barcode, pindai, lalu Enter. Label detail barang mencetak Code 128 dan QR tanpa layanan eksternal.

## Skenario uji manual

| Langkah | Hasil yang diharapkan |
|---|---|
| Masuk sebagai admin dan buka menu Barang Masuk | Halaman POS tampil, kursor fokus di input barcode |
| Pindai barcode USB dan tekan Enter | Barang muncul satu kali di keranjang; stok belum berubah |
| Pindai barang yang sama lagi | Jumlah pada baris yang sama bertambah |
| Cari dengan potongan nama/kode lalu pilih hasil | Barang ditambahkan ke keranjang |
| Ubah jumlah dan tekan Simpan Barang Masuk | Detail transaksi tampil; stok bertambah; ada satu detail, satu ledger, satu audit |
| Buka Barang Keluar tanpa penerima | Server menolak input penerima kosong |
| Simpan jumlah barang keluar di bawah stok tersedia | Transaksi sukses; stok turun sesuai jumlah |
| Coba mengeluarkan barang melebihi stok | Pesan stok yang tersedia tampil; transaksi dan ledger tidak dibuat |
| Keranjang berisi beberapa barang, salah satunya kurang stok | Seluruh transaksi batal; stok semua barang tidak berubah |
| Buka detail barang dan cetak label | Barcode Code 128 dan QR tercetak; layar aplikasi tidak ikut tercetak |
| Buka Riwayat Transaksi, filter tanggal/jenis/nomor | Daftar sesuai filter; detail transaksi tidak menyediakan aksi edit/hapus |

## Query pemeriksaan MySQL

Nomor berurutan per hari dan jenis:

```sql
SELECT tipe, tanggal, terakhir
FROM nomor_urut
ORDER BY tanggal DESC, tipe;
```

Cek saldo barang terhadap ledger terbaru berdasarkan ID (ledger tidak diubah/dihapus):

```sql
SELECT b.id, b.kode_barang, b.stok AS stok_barang,
       sm.stok_sesudah AS saldo_ledger_terakhir
FROM barang b
LEFT JOIN stok_mutasi sm
  ON sm.id = (
      SELECT sm2.id
      FROM stok_mutasi sm2
      WHERE sm2.barang_id = b.id
      ORDER BY sm2.id DESC
      LIMIT 1
  )
WHERE b.deleted_at IS NULL
  AND (sm.id IS NULL OR b.stok <> sm.stok_sesudah);
```

Hasil query invarian seharusnya kosong. Pemeriksaan ringkas volume transaksi:

```sql
SELECT t.nomor_transaksi, COUNT(DISTINCT td.barang_id) AS jenis_barang,
       COUNT(sm.id) AS jumlah_ledger
FROM transactions t
JOIN transaction_details td ON td.transaction_id = t.id
LEFT JOIN stok_mutasi sm ON sm.transaction_detail_id = td.id
GROUP BY t.id, t.nomor_transaksi
HAVING jenis_barang <> jumlah_ledger;
```

Hasil query seharusnya kosong; setiap detail transaksi memiliki satu baris ledger.

## Pengujian otomatis dan audit pra-serah

Perintah:

```powershell
php artisan test
npm run build
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools\audit.ps1 .
```

Hasil pada workspace ini:

| Pemeriksaan | Hasil |
|---|---|
| `php artisan test --compact` | 108 lulus, 501 asersi |
| `npm run build` | Berhasil; Vite mengompilasi 285 modul |
| PHP lint | 127 berkas PHP diperiksa oleh audit PowerShell; 0 masalah |
| Blade | 22 view; keseimbangan direktif diperiksa |
| Referensi Blade | 3 `@include`, 24 komponen; semua ditemukan |
| Rute | 38 nama terdaftar; 48 `route()` cocok; `routeIs()` cocok |
| `view()` di aplikasi | 15 referensi; semua view ditemukan |
| Rute ke controller | Semua controller dan metode yang terdaftar ditemukan |
| `git diff --check` | Bersih |

Lingkungan tidak menyediakan Python, jadi `tools/audit.py` tidak dijalankan. Audit setara untuk lint PHP, direktif Blade, include/komponen, route/view, dan metode controller dijalankan dengan `tools/audit.ps1`. Migration MySQL dan pemeriksaan browser langsung belum dijalankan; PHPUnit memakai SQLite memori. Dua kerentanan kritis tercatat oleh `npm install` di seluruh pohon dependensi saat ini; audit dependency terpisah belum dilakukan pada tahap ini.

## Temuan dan koreksi

| Temuan | Koreksi |
|---|---|
| README sebelumnya menyatakan cakupan berhenti di Tahap 2, padahal kode Tahap 3 sudah ada | README diperbarui menjadi dokumentasi kumulatif Tahap 1–4 |
| Nomor urut belum punya layanan transaksi | Ditambahkan `NomorTransaksiService` yang mengunci baris urut per jenis/tanggal |
| Belum ada alur stok masuk/keluar atomik | Ditambahkan `StokService` dengan lock barang berurutan, validasi stok, detail, ledger, dan audit di satu transaksi |
| Belum ada POS, pencarian barcode, daftar transaksi, atau detail | Ditambahkan halaman, rute, validasi server, dan pencarian barang aktif |
| Detail barang belum bisa mencetak barcode/QR | Ditambahkan JsBarcode dan QRCode lokal serta CSS cetak |
| Python tidak tersedia untuk audit bawaan | Ditambahkan audit PowerShell `tools/audit.ps1`; false positive cabang `@empty` pada `@forelse` diperbaiki |

## Tahap berikutnya

Tahap 4 selesai dan menunggu pengujian pengguna. Jangan mulai Tahap 5 sebelum ada persetujuan. Tahap 5 mencakup scan kamera, kartu stok, histori transaksi pada detail barang, dan penyesuaian stok. Sesuai urutan yang disepakati, Tahap 6 berisi dashboard dan laporan; Tahap 7 berisi hardening, uji race condition/rollback/invarian, UX responsif, pengaturan, dan dokumentasi lanjutan.
