<x-layouts.app title="Riwayat Transaksi" :breadcrumbs="['Transaksi' => null, 'Riwayat Transaksi' => null]">
    <div class="d-flex flex-wrap gap-2 mb-3">
        <a href="{{ route('transaksi.masuk.cepat') }}" class="btn btn-success"><i class="bi bi-plus-circle me-1"></i> Barang Masuk</a>
        <a href="{{ route('transaksi.keluar.cepat') }}" class="btn btn-primary"><i class="bi bi-dash-circle me-1"></i> Barang Keluar</a>
    </div>
    <div class="card mb-4"><div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3"><label class="form-label" for="tipe">Jenis transaksi</label><select class="form-select" name="tipe" id="tipe"><option value="">Semua jenis</option><option value="masuk" @selected(request('tipe') === 'masuk')>Barang Masuk</option><option value="keluar" @selected(request('tipe') === 'keluar')>Barang Keluar</option></select></div>
            <div class="col-md-2"><label class="form-label" for="dari">Dari tanggal</label><input class="form-control" type="date" name="dari" id="dari" value="{{ request('dari') }}"></div>
            <div class="col-md-2"><label class="form-label" for="sampai">Sampai tanggal</label><input class="form-control" type="date" name="sampai" id="sampai" value="{{ request('sampai') }}"></div>
            <div class="col-md-3"><label class="form-label" for="q">Nomor transaksi</label><input class="form-control" name="q" id="q" value="{{ request('q') }}" placeholder="Cari nomor"></div>
            <div class="col-md-2 d-flex gap-2"><button class="btn btn-primary flex-grow-1"><i class="bi bi-search"></i> Filter</button><a class="btn btn-outline-secondary" href="{{ route('transaksi.index') }}" aria-label="Hapus filter"><i class="bi bi-x-lg"></i></a></div>
        </form>
    </div></div>
    <div class="card"><div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><th>Nomor</th><th>Tanggal</th><th>Jenis</th><th>Tujuan / penerima</th><th>Petugas</th><th class="text-center">Jenis barang</th><th></th></tr></thead>
            <tbody>
                @forelse ($transaksi as $item)
                    <tr>
                        <td class="font-monospace fw-semibold"><a href="{{ route('transaksi.show', $item) }}">{{ $item->nomor_transaksi }}</a></td>
                        <td>{{ $item->tanggal->translatedFormat('d M Y') }}</td>
                        <td><span class="badge {{ $item->tipe === \App\Enums\TipeTransaksi::Masuk ? 'text-bg-success' : 'text-bg-primary' }}">{{ $item->tipe->label() }}</span></td>
                        <td>{{ $item->tujuan ?: '—' }}</td>
                        <td>{{ $item->user->name }}</td>
                        <td class="text-center">{{ $item->details_count }}</td>
                        <td class="text-end"><a href="{{ route('transaksi.show', $item) }}" class="btn btn-sm btn-outline-secondary">Detail</a></td>
                    </tr>
                @empty
                    <tr><td colspan="7" class="text-center text-secondary py-5">Belum ada transaksi sesuai filter.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if ($transaksi->hasPages())<div class="card-footer bg-white">{{ $transaksi->links() }}</div>@endif
    </div>
</x-layouts.app>
