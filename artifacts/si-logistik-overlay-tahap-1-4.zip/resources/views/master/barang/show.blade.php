<x-layouts.app title="Detail Barang" :breadcrumbs="['Master Data' => null, 'Data Barang' => route('master.barang.index'), $barang->nama_barang => null]">
    <div class="row g-4" data-halaman-detail-barang>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body text-center">
                    @if ($barang->foto_url)
                        <img src="{{ $barang->foto_url }}" alt="Foto {{ $barang->nama_barang }}" class="img-fluid rounded border mb-3" style="max-height: 280px;">
                    @else
                        <div class="ratio ratio-1x1 border rounded bg-light mb-3">
                            <div class="d-flex flex-column align-items-center justify-content-center text-secondary">
                                <i class="bi bi-image fs-1"></i>
                                <small>Belum ada foto</small>
                            </div>
                        </div>
                    @endif
                    <h2 class="h5 mb-1">{{ $barang->nama_barang }}</h2>
                    <div class="mb-2"><x-badge-stok :status="$barang->status_stok" /></div>
                    @unless ($barang->is_active)
                        <span class="badge text-bg-secondary">Nonaktif</span>
                    @endunless
                </div>
                <div class="card-footer d-flex gap-2 justify-content-center bg-white">
                    <a href="{{ route('master.barang.edit', $barang) }}" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square me-1"></i> Ubah</a>
                    <button type="button" class="btn btn-outline-danger btn-sm"
                            data-confirm-delete
                            data-redirect="1"
                            data-url="{{ route('master.barang.destroy', $barang) }}"
                            data-pesan="Hapus barang &quot;{{ $barang->nama_barang }}&quot;? Histori transaksi tetap tersimpan.">
                        <i class="bi bi-trash me-1"></i> Hapus
                    </button>
                    <a href="{{ route('master.barang.index') }}" class="btn btn-outline-secondary btn-sm">Kembali</a>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">Informasi barang</div>
                <div class="card-body">
                    <dl class="row mb-0">
                        <dt class="col-sm-4 text-secondary fw-normal">Kode barang</dt>
                        <dd class="col-sm-8">{{ $barang->kode_barang }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Barcode</dt>
                        <dd class="col-sm-8 font-monospace">{{ $barang->barcode }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Kategori</dt>
                        <dd class="col-sm-8">{{ $barang->kategori?->nama }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Satuan</dt>
                        <dd class="col-sm-8">{{ $barang->satuan?->nama }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Lokasi penyimpanan</dt>
                        <dd class="col-sm-8">{{ $barang->lokasi?->nama }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Stok saat ini</dt>
                        <dd class="col-sm-8 fw-semibold">{{ \App\Support\Format::angka($barang->stok) }} {{ $barang->satuan?->nama }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Stok minimum</dt>
                        <dd class="col-sm-8">{{ \App\Support\Format::angka($barang->stok_minimum) }} {{ $barang->satuan?->nama }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Harga</dt>
                        <dd class="col-sm-8">{{ \App\Support\Format::rupiah($barang->harga) }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Deskripsi</dt>
                        <dd class="col-sm-8">{!! nl2br(e($barang->deskripsi ?? '-')) !!}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Dibuat</dt>
                        <dd class="col-sm-8">{{ $barang->created_at?->translatedFormat('d F Y H:i') }}</dd>
                        <dt class="col-sm-4 text-secondary fw-normal">Diperbarui</dt>
                        <dd class="col-sm-8 mb-0">{{ $barang->updated_at?->translatedFormat('d F Y H:i') }}</dd>
                    </dl>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <span>Barcode dan label</span>
                    <button type="button" class="btn btn-sm btn-outline-primary transaksi-actions" onclick="window.print()"><i class="bi bi-printer me-1"></i> Cetak label</button>
                </div>
                <div class="card-body">
                    @include('master.barang._label', ['barang' => $barang])
                </div>
            </div>

            <div class="card">
                <div class="card-header">Riwayat transaksi barang</div>
                <div class="card-body text-center text-secondary py-4">
                    <i class="bi bi-clock-history fs-2"></i>
                    <p class="mb-0 mt-2">Transaksi barang ini akan tercatat di kartu stok pada Tahap 5.</p>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
